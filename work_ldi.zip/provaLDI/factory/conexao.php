<?php
    $servidor ="localhost:3306";
    $user ="root";
    $senha = "";
    $banco = "bdescola";
    $conn = mysqli_connect($servidor, $user, $senha, $banco);
    ?>

    