<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://static.vecteezy.com/ti/vetor-gratis/p1/5263685-conceito-de-volta-escola-computador-ou-laptop-com-icone-de-educacao-flutuando-no-ar-no-fundo-roxo-e-violeta-e-learning-or-study-online-vetor.jpg" type="image/png">
    <title>Aluno</title>
</head>
<body>
<style>
        body{
            background-color: blue;
        }
    </style>
</body>
</html>