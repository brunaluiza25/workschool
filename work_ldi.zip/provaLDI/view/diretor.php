<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://static.vecteezy.com/ti/vetor-gratis/p1/5263685-conceito-de-volta-escola-computador-ou-laptop-com-icone-de-educacao-flutuando-no-ar-no-fundo-roxo-e-violeta-e-learning-or-study-online-vetor.jpg" type="image/png">
    <title>Diretor</title>
</head>
<body>
    <style>
        body {
            background-color: green;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            padding: 50px;
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 40px;
        }

        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        button {
            background-color: #4CAF50; /* Cor de fundo verde */
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 1.2em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049; /* Cor de fundo verde mais escuro ao passar o mouse */
        }
    </style>

    <h1>Acesso Ilimitado - Diretor</h1>

    <div class="buttons-container">
        <!-- Botão para acessar a página de professores -->
        <a href="professor.php">
            <button>Acessar Professores</button>
        </a>

        <!-- Botão para acessar a página de alunos -->
        <a href="aluno.php">
            <button>Acessar Alunos</button>
        </a>
    </div>
</body>
</html>