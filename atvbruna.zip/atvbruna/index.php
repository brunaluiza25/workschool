<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School</title>
    <link rel="icon" href="https://static.vecteezy.com/ti/vetor-gratis/p1/5263685-conceito-de-volta-escola-computador-ou-laptop-com-icone-de-educacao-flutuando-no-ar-no-fundo-roxo-e-violeta-e-learning-or-study-online-vetor.jpg" type="image/png">
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <header>
        <h1>Bem-vindo ao School</h1>
    </header>
    <main>
        <form action="model/verificador.php" method="POST">
            <label for="email">E-mail: </label>
            <input type="text" name="cxemail" id="email" required>
            <label for="senha">Senha: </label>
            <input type="text" name="cxsenha" id="senha" required>
            <input type="submit" value="Enviar">
        </form>
        <div class="user-list">
            <h2>Usuários Cadastrados</h2>
            <table>
                <thead>
                    <tr>
                        <th>E-mail</th>
                        <th>Senha</th>
                        <th>Tipo</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>diretor@gmail.com</td>
                        <td>123</td>
                        <td>Diretor</td>
                    </tr>
                    <tr>
                        <td>professor@gmail.com</td>
                        <td>123</td>
                        <td>Professor</td>
                    </tr>
                    <tr>
                        <td>aluno@gmail.com</td>
                        <td>123</td>
                        <td>Aluno</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Bruna Luiza Paixão 3°INFO. </br>IFSP - GRU</p>
    </footer>
</body>
</html>
