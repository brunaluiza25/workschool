<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://static.vecteezy.com/ti/vetor-gratis/p1/5263685-conceito-de-volta-escola-computador-ou-laptop-com-icone-de-educacao-flutuando-no-ar-no-fundo-roxo-e-violeta-e-learning-or-study-online-vetor.jpg" type="image/png">
    <title>Aluno</title>
    <style>
        body {
            background-color: blue;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            padding: 50px;
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 40px;
        }

        img {
            margin-top: 20px;
            max-width: 100%;
            height: auto;
            border-radius: 15px; /* Cantos arredondados */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Sombra */
        }
    </style>
</head>
<body>
    <h1>Aluno</h1>
    <img src="https://cdn-icons-png.flaticon.com/512/3413/3413591.png" alt="Imagem ilustrativa de aluno">
</body>
</html>
