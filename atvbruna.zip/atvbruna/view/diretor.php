<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://static.vecteezy.com/ti/vetor-gratis/p1/5263685-conceito-de-volta-escola-computador-ou-laptop-com-icone-de-educacao-flutuando-no-ar-no-fundo-roxo-e-violeta-e-learning-or-study-online-vetor.jpg" type="image/png">
    <title>Diretor</title>
</head>
<body>
    <style>
        body {
            background-color: green;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            padding: 50px;
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 40px;
        }

        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 1.2em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049; 
        }

        img {
            margin-top: 20px;
            max-width: 100%;
            height: auto;
            border-radius: 15px; /* Cantos arredondados */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Sombra */
        }
    </style>

    <h1>Acesso Ilimitado - Diretor</h1>

    <div class="buttons-container">
        <a href="professor.php">
            <button>Acessar Professores</button>
        </a>

        <a href="aluno.php">
            <button>Acessar Alunos</button>
        </a>
    </div>

    <img src="https://cdn-icons-png.flaticon.com/512/3152/3152902.png" alt="Imagem ilustrativa de diretor">
</body>
</html>